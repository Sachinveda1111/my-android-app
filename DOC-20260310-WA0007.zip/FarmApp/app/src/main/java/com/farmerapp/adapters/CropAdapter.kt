package com.farmerapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.databinding.ItemCropCardBinding
import com.farmerapp.models.Crop

class CropAdapter(
    private val crops: MutableList<Crop>,
    private val onCropClick: (Crop) -> Unit
) : RecyclerView.Adapter<CropAdapter.CropViewHolder>() {

    inner class CropViewHolder(val binding: ItemCropCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        CropViewHolder(ItemCropCardBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = crops.size

    override fun onBindViewHolder(holder: CropViewHolder, position: Int) {
        val crop = crops[position]
        with(holder.binding) {
            tvCropIcon.text = crop.emoji
            tvCropName.text = crop.name
            tvCropVariety.text = "Variety: ${crop.variety}"
            tvCropStatus.text = crop.status
            tvPlantDate.text = "📅 Planted: ${crop.plantDate}"
            tvHarvestDate.text = "🌾 Harvest: ${crop.harvestDate}"
            progressGrowth.progress = crop.growthPercent
            tvGrowthPercent.text = "${crop.growthPercent}% Growth"

            val statusColor = when (crop.status) {
                "Ready to Harvest" -> android.graphics.Color.parseColor("#F9A825")
                "Harvested" -> android.graphics.Color.parseColor("#00695C")
                "Failed" -> android.graphics.Color.parseColor("#D32F2F")
                else -> android.graphics.Color.parseColor("#2E7D32")
            }
            tvCropStatus.setTextColor(statusColor)

            root.setOnClickListener { onCropClick(crop) }
        }
    }

    fun updateList(newList: List<Crop>) {
        crops.clear()
        crops.addAll(newList)
        notifyDataSetChanged()
    }
}
