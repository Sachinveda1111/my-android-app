package com.farmerapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.adapters.CropAdapter
import com.farmerapp.databinding.FragmentCropManagementBinding
import com.farmerapp.utils.SampleData

class CropManagementFragment : Fragment() {
    private var _binding: FragmentCropManagementBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCropManagementBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val allCrops = SampleData.getCrops()

        binding.rvCrops.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = CropAdapter(allCrops.toMutableList()) { crop ->
                Toast.makeText(requireContext(), "Crop: ${crop.name} - ${crop.status}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnAddCrop.setOnClickListener {
            Toast.makeText(requireContext(), "Add new crop feature - opens dialog", Toast.LENGTH_SHORT).show()
        }

        binding.chipGroup.setOnCheckedStateChangeListener { group, checkedIds ->
            val filteredCrops = when {
                checkedIds.isEmpty() -> allCrops
                else -> {
                    val chip = group.findViewById<com.google.android.material.chip.Chip>(checkedIds[0])
                    when (chip?.text.toString()) {
                        "Growing" -> allCrops.filter { it.status == "Growing" }
                        "Ready to Harvest" -> allCrops.filter { it.status == "Ready to Harvest" }
                        "Harvested" -> allCrops.filter { it.status == "Harvested" }
                        else -> allCrops
                    }
                }
            }
            (binding.rvCrops.adapter as CropAdapter).updateList(filteredCrops)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
