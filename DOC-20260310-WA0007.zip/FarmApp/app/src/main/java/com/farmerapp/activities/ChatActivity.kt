package com.farmerapp.activities

import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.adapters.ChatAdapter
import com.farmerapp.databinding.ActivityChatBinding
import com.farmerapp.models.ChatMessage
import com.farmerapp.utils.SampleData
import java.text.SimpleDateFormat
import java.util.*

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        messages.addAll(SampleData.getInitialChatMessages())
        adapter = ChatAdapter(messages)

        binding.rvMessages.apply {
            layoutManager = LinearLayoutManager(this@ChatActivity).apply {
                stackFromEnd = true
            }
            adapter = this@ChatActivity.adapter
        }

        binding.btnSend.setOnClickListener {
            val text = binding.etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

            // Add user message
            messages.add(ChatMessage(UUID.randomUUID().toString(), text, true, time))
            adapter.notifyItemInserted(messages.size - 1)
            binding.rvMessages.smoothScrollToPosition(messages.size - 1)
            binding.etMessage.text?.clear()

            // Hide keyboard
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(binding.etMessage.windowToken, 0)

            // AI response after delay
            binding.rvMessages.postDelayed({
                val response = SampleData.getAIResponse(text)
                messages.add(ChatMessage(UUID.randomUUID().toString(), response, false, time))
                adapter.notifyItemInserted(messages.size - 1)
                binding.rvMessages.smoothScrollToPosition(messages.size - 1)
            }, 800)
        }
    }
}
