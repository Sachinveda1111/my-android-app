package com.farmerapp.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.activities.ChatActivity
import com.farmerapp.activities.FarmReportActivity
import com.farmerapp.adapters.ActivityAdapter
import com.farmerapp.databinding.FragmentDashboardBinding
import com.farmerapp.utils.SampleData
import com.farmerapp.utils.SessionManager
import java.util.Calendar

class DashboardFragment : Fragment() {
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val session = SessionManager(requireContext())
        binding.tvFarmerName.text = session.getUserName()
        binding.tvFarmLocation.text = "📍 ${session.getFarmLocation()}"
        binding.tvFarmSize.text = "${session.getFarmSize()} ac"

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        binding.tvGreeting.text = when {
            hour < 12 -> "Good Morning, 👋"
            hour < 17 -> "Good Afternoon, 👋"
            else -> "Good Evening, 👋"
        }

        binding.rvRecentActivity.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = ActivityAdapter(SampleData.getRecentActivities())
        }

        binding.cardCrops.setOnClickListener {
            parentFragmentManager.let {
                requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                    com.farmerapp.R.id.bottomNavView
                ).selectedItemId = com.farmerapp.R.id.nav_crops
            }
        }

        binding.cardFertilizer.setOnClickListener {
            requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.farmerapp.R.id.bottomNavView
            ).selectedItemId = com.farmerapp.R.id.nav_fertilizer
        }

        binding.cardExpense.setOnClickListener {
            requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.farmerapp.R.id.bottomNavView
            ).selectedItemId = com.farmerapp.R.id.nav_expense
        }

        binding.cardWeather.setOnClickListener {
            requireActivity().findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.farmerapp.R.id.bottomNavView
            ).selectedItemId = com.farmerapp.R.id.nav_weather
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
