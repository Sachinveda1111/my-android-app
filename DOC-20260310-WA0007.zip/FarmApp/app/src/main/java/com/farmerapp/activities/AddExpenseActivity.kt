package com.farmerapp.activities

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.farmerapp.databinding.ActivityAddExpenseBinding
import java.text.SimpleDateFormat
import java.util.*

class AddExpenseActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddExpenseBinding
    private var isExpense = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddExpenseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Add Transaction"

        val categories = arrayOf("Seeds", "Fertilizer", "Labour", "Equipment", "Irrigation", "Pesticide", "Transport", "Sale", "Subsidy", "Other")
        val cropNames = arrayOf("Wheat", "Rice", "Tomato", "Maize", "Cotton", "Potato", "None")

        binding.etCategory.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories))
        binding.etCrop.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cropNames))

        // Set today's date
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        binding.etDate.setText(today)

        binding.etDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, day ->
                binding.etDate.setText("$day ${SimpleDateFormat("MMM", Locale.getDefault()).format(Calendar.getInstance().also {
                    it.set(year, month, day)
                }.time)} $year")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding.toggleType.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                isExpense = checkedId == binding.btnExpenseType.id
            }
        }

        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString().trim()
            val amount = binding.etAmount.text.toString().trim()
            if (title.isEmpty() || amount.isEmpty()) {
                Toast.makeText(this, "Please fill title and amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "${if (isExpense) "Expense" else "Income"} of ₹$amount saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
