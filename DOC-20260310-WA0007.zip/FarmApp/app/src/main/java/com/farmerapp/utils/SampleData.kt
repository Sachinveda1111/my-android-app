package com.farmerapp.utils

import com.farmerapp.models.*

object SampleData {

    fun getCrops(): List<Crop> = listOf(
        Crop("1", "Wheat", "HD-2967", "🌾", "Growing", "Jan 10", "Apr 15", 5.0, 65),
        Crop("2", "Rice", "Basmati 370", "🌾", "Growing", "Jun 20", "Oct 10", 3.0, 40),
        Crop("3", "Tomato", "Hybrid F1", "🍅", "Ready to Harvest", "Sep 1", "Dec 5", 1.5, 95),
        Crop("4", "Maize", "DHM-117", "🌽", "Growing", "Jul 5", "Nov 20", 4.0, 55),
        Crop("5", "Cotton", "BT Cotton", "🌿", "Harvested", "Apr 15", "Sep 30", 6.0, 100),
        Crop("6", "Potato", "Kufri Jyoti", "🥔", "Growing", "Nov 10", "Feb 20", 2.0, 30)
    )

    fun getExpenses(): List<Expense> = listOf(
        Expense("1", "Wheat Seeds Purchase", 3500.0, true, "Seeds", "Jan 10", "Wheat", "🌱"),
        Expense("2", "Wheat Sold to Market", 22000.0, false, "Sale", "Feb 15", "Wheat", "💰"),
        Expense("3", "Urea Fertilizer", 2800.0, true, "Fertilizer", "Jan 20", "Rice", "🧪"),
        Expense("4", "Labour for Harvesting", 5000.0, true, "Labour", "Feb 28", "Cotton", "👷"),
        Expense("5", "Irrigation Pump Repair", 1200.0, true, "Equipment", "Jan 25", "", "⚙️"),
        Expense("6", "Tomato Sold", 18000.0, false, "Sale", "Dec 10", "Tomato", "💰"),
        Expense("7", "Pesticide Spray", 950.0, true, "Fertilizer", "Feb 5", "Rice", "🧪"),
        Expense("8", "Tractor Rent", 3500.0, true, "Equipment", "Jan 18", "", "🚜")
    )

    fun getDiseases(): List<Disease> = listOf(
        Disease("Leaf Blight", "Wheat, Rice", "HIGH",
            "Yellow/brown lesions on leaves, wilting, reduced yield. Affected areas show necrotic patches.",
            "Apply Mancozeb 75WP @ 2.5 g/L water. Remove infected plants. Spray every 10 days.", "🦠"),
        Disease("Powdery Mildew", "Wheat, Tomato", "MEDIUM",
            "White powdery coating on leaves, stems. Distorted new growth and leaf drop.",
            "Use Sulphur 80WP @ 3 g/L or Hexaconazole 5SC @ 2 mL/L. Improve air circulation.", "🍄"),
        Disease("Root Rot", "Cotton, Maize", "HIGH",
            "Wilting despite adequate water, dark brown roots, stunted growth, plant death.",
            "Seed treatment with Carbendazim. Improve drainage. Apply Trichoderma viride @ 2.5 kg/ha.", "🌱"),
        Disease("Aphid Infestation", "All Crops", "MEDIUM",
            "Curling leaves, sticky residue (honeydew), yellowing. Clusters of small insects.",
            "Spray Imidacloprid 17.8 SL @ 0.5 mL/L. Use neem oil @ 5 mL/L. Release ladybugs.", "🐛"),
        Disease("Bacterial Wilt", "Tomato, Potato", "HIGH",
            "Sudden wilting, yellowing leaves, brown stem discoloration, ooze from stem cut.",
            "No cure once infected. Remove and destroy plants. Use resistant varieties next season.", "💀")
    )

    fun getFertilizerTips(): List<FertilizerTip> = listOf(
        FertilizerTip("Wheat", "Basal (Before Sowing)", "DAP (Di-Ammonium Phosphate)", "120 kg/ha", "Before sowing, mix with soil", "Provides P and N for root development", "🌾"),
        FertilizerTip("Wheat", "Tillering Stage", "Urea", "65 kg/ha", "21-25 days after sowing with irrigation", "Critical for tillering and leaf growth", "🌾"),
        FertilizerTip("Rice", "Transplanting", "NPK 12:32:16", "100 kg/ha", "At the time of transplanting", "Balanced nutrition for establishment", "🌾"),
        FertilizerTip("Tomato", "Vegetative Stage", "19:19:19 NPK", "5 g/L water spray", "Every 15 days foliar spray", "Promotes healthy vegetative growth", "🍅"),
        FertilizerTip("Maize", "Top Dressing", "Urea", "65 kg/ha", "30 days after sowing", "Apply before irrigation or rain", "🌽"),
        FertilizerTip("Cotton", "Flowering Stage", "Potassium Nitrate", "10 g/L water", "Foliar spray at flowering", "Improves boll development and yield", "🌿")
    )

    fun getWeatherForecast(): List<WeatherDay> = listOf(
        WeatherDay("Today", "⛅", "Partly Cloudy", 28, 18),
        WeatherDay("Tomorrow", "🌧️", "Rainy", 24, 16),
        WeatherDay("Wednesday", "🌦️", "Light Showers", 26, 17),
        WeatherDay("Thursday", "☀️", "Sunny", 32, 20),
        WeatherDay("Friday", "⛅", "Partly Cloudy", 30, 19),
        WeatherDay("Saturday", "☀️", "Clear Sky", 33, 22),
        WeatherDay("Sunday", "🌤", "Mostly Sunny", 31, 21)
    )

    fun getRecentActivities(): List<ActivityItem> = listOf(
        ActivityItem("🌱", "Crop Added", "Wheat - HD-2967 planted in Field 2", "2 hrs ago"),
        ActivityItem("💸", "Expense Logged", "Purchased Urea fertilizer ₹2,800", "5 hrs ago"),
        ActivityItem("🌧️", "Weather Alert", "Rain expected tomorrow - adjust irrigation", "1 day ago"),
        ActivityItem("🌾", "Harvest Ready", "Tomato crop ready for harvest in Field 1", "2 days ago"),
        ActivityItem("🤖", "AI Suggestion", "Apply DAP before upcoming rain for wheat", "2 days ago")
    )

    fun getInitialChatMessages(): List<ChatMessage> = listOf(
        ChatMessage("1", "Hello! I'm AgriBot, your smart farming assistant. Ask me anything about crops, fertilizers, weather, or farming practices!", false, "Just now")
    )

    fun getAIResponse(query: String): String {
        val lowerQuery = query.lowercase()
        return when {
            lowerQuery.contains("wheat") -> "For wheat cultivation:\n🌾 Best varieties: HD-2967, PBW-550\n💧 Water: 4-5 irrigations needed\n🧪 Fertilizer: 120 kg DAP + 65 kg Urea/ha\n📅 Sowing: Oct-Nov, Harvest: Mar-Apr\n⚠️ Watch for leaf blight and rust diseases."
            lowerQuery.contains("rice") || lowerQuery.contains("paddy") -> "For rice/paddy cultivation:\n🌾 Popular varieties: Basmati, PR-126\n💧 Needs flooded conditions for 60-70 days\n🧪 NPK: 120:60:40 kg/ha\n🌡️ Optimal temp: 25-35°C\n⚠️ Common issues: Blast disease, stem borer"
            lowerQuery.contains("fertilizer") -> "Fertilizer guidelines:\n🌱 NPK ratio depends on crop stage\n• Basal: DAP + MOP before sowing\n• Top dressing: Urea at tillering\n• Micronutrients: ZnSO4 @ 25 kg/ha\n💡 Tip: Soil test first for accurate recommendations!"
            lowerQuery.contains("weather") || lowerQuery.contains("rain") -> "Current weather insights:\n⛅ Today: 28°C Partly Cloudy\n🌧️ Tomorrow: Rain expected\n💡 Farm tips:\n• Avoid spraying pesticides today\n• Plan irrigation considering upcoming rain\n• Harvest tomatoes before rain if ready"
            lowerQuery.contains("disease") || lowerQuery.contains("pest") -> "Common crop diseases & management:\n🦠 Leaf Blight: Mancozeb 75WP @ 2.5g/L\n🍄 Powdery Mildew: Sulphur 80WP @ 3g/L\n🐛 Aphids: Imidacloprid 0.5mL/L\n💡 Prevention is better than cure. Monitor crops weekly!"
            lowerQuery.contains("tomato") -> "Tomato cultivation tips:\n🍅 Variety: Hybrid F1 for high yield\n💧 Drip irrigation recommended\n🧪 Calcium + Boron spray prevents blossom end rot\n📅 Staking required after 30 days\n⚠️ Watch for bacterial wilt and leaf curl virus"
            lowerQuery.contains("profit") || lowerQuery.contains("income") -> "Farm profitability tips:\n💰 Diversify crops to spread risk\n📊 Track all expenses vs income\n🌾 Consider contract farming for guaranteed prices\n💡 Add value: sell processed products\n📈 Your current profit margin looks good at 45%!"
            else -> "Great question! Here are some general farming tips:\n🌱 Rotate crops every season to maintain soil health\n💧 Use drip irrigation to save 40-50% water\n🧪 Get soil tested annually\n📱 Monitor weather forecasts daily\n🤝 Join farmer groups for market insights\n\nAsk me specifically about any crop, disease, or farming practice!"
        }
    }
}
