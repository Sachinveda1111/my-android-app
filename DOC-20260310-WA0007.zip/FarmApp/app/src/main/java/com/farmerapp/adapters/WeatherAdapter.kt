package com.farmerapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.databinding.ItemWeatherDayBinding
import com.farmerapp.models.WeatherDay

class WeatherAdapter(private val days: List<WeatherDay>) : RecyclerView.Adapter<WeatherAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemWeatherDayBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemWeatherDayBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = days.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val day = days[position]
        with(holder.binding) {
            tvDay.text = day.day
            tvDayIcon.text = day.icon
            tvDayCondition.text = day.condition
            tvDayTemp.text = "${day.highTemp}° / ${day.lowTemp}°"
        }
    }
}
