package com.farmerapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.R
import com.farmerapp.models.Crop

class CropPerformanceAdapter(private val crops: List<Crop>) : RecyclerView.Adapter<CropPerformanceAdapter.ViewHolder>() {

    inner class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvEmoji: TextView = view.findViewById(R.id.tvPerfEmoji)
        val tvName: TextView = view.findViewById(R.id.tvPerfCropName)
        val tvArea: TextView = view.findViewById(R.id.tvPerfArea)
        val tvStatus: TextView = view.findViewById(R.id.tvPerfStatus)
        val progressBar: ProgressBar = view.findViewById(R.id.progressPerf)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_crop_performance, parent, false))

    override fun getItemCount() = crops.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val crop = crops[position]
        holder.tvEmoji.text = crop.emoji
        holder.tvName.text = crop.name
        holder.tvArea.text = "${crop.area} acres"
        holder.tvStatus.text = crop.status
        holder.progressBar.progress = crop.growthPercent
    }
}
