package com.farmerapp.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.activities.AddExpenseActivity
import com.farmerapp.adapters.ExpenseAdapter
import com.farmerapp.databinding.FragmentExpenseTrackerBinding
import com.farmerapp.utils.SampleData

class ExpenseTrackerFragment : Fragment() {
    private var _binding: FragmentExpenseTrackerBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExpenseTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val allExpenses = SampleData.getExpenses()
        val totalExpenses = allExpenses.filter { it.isExpense }.sumOf { it.amount }
        val totalIncome = allExpenses.filter { !it.isExpense }.sumOf { it.amount }
        val netProfit = totalIncome - totalExpenses

        binding.tvTotalExpenses.text = "₹${String.format("%,.0f", totalExpenses)}"
        binding.tvTotalIncome.text = "₹${String.format("%,.0f", totalIncome)}"
        binding.tvNetProfit.text = "₹${String.format("%,.0f", netProfit)}"

        binding.rvExpenses.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = ExpenseAdapter(allExpenses.toMutableList())
        }

        binding.btnAddExpense.setOnClickListener {
            startActivity(Intent(requireContext(), AddExpenseActivity::class.java))
        }

        binding.chipGroupCategory.setOnCheckedStateChangeListener { group, checkedIds ->
            val filtered = if (checkedIds.isEmpty()) allExpenses
            else {
                val chip = group.findViewById<com.google.android.material.chip.Chip>(checkedIds[0])
                when (chip?.text.toString()) {
                    "All" -> allExpenses
                    else -> allExpenses.filter { it.category == chip?.text.toString() }
                }
            }
            (binding.rvExpenses.adapter as ExpenseAdapter).updateList(filtered)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
