package com.farmerapp.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.farmerapp.databinding.ActivityRegisterBinding
import com.farmerapp.utils.SessionManager

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        session = SessionManager(this)

        binding.btnRegister.setOnClickListener {
            val name = binding.etFullName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val location = binding.etLocation.text.toString().trim()
            val farmSize = binding.etFarmSize.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val confirmPassword = binding.etConfirmPassword.text.toString().trim()

            when {
                name.isEmpty() -> showError("Please enter your full name")
                phone.isEmpty() -> showError("Please enter phone number")
                email.isEmpty() -> showError("Please enter email")
                location.isEmpty() -> showError("Please enter farm location")
                farmSize.isEmpty() -> showError("Please enter farm size")
                password.isEmpty() -> showError("Please create a password")
                password != confirmPassword -> showError("Passwords do not match")
                password.length < 6 -> showError("Password must be at least 6 characters")
                else -> {
                    session.saveUser(name, email, location, farmSize)
                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finishAffinity()
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            finish()
        }
    }

    private fun showError(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
