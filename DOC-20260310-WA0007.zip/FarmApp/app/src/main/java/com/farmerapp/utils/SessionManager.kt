package com.farmerapp.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("FarmApp", Context.MODE_PRIVATE)

    companion object {
        const val KEY_IS_LOGGED_IN = "isLoggedIn"
        const val KEY_USER_NAME = "userName"
        const val KEY_USER_EMAIL = "userEmail"
        const val KEY_FARM_LOCATION = "farmLocation"
        const val KEY_FARM_SIZE = "farmSize"
    }

    fun saveUser(name: String, email: String, location: String, farmSize: String) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_FARM_LOCATION, location)
            putString(KEY_FARM_SIZE, farmSize)
            apply()
        }
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "Farmer") ?: "Farmer"
    fun getFarmLocation(): String = prefs.getString(KEY_FARM_LOCATION, "My Farm") ?: "My Farm"
    fun getFarmSize(): String = prefs.getString(KEY_FARM_SIZE, "0") ?: "0"
    fun getUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""

    fun logout() {
        prefs.edit().clear().apply()
    }
}
