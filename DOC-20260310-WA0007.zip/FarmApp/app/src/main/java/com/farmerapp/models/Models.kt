package com.farmerapp.models

data class User(
    val id: String = "",
    val fullName: String = "",
    val phone: String = "",
    val email: String = "",
    val farmLocation: String = "",
    val farmSize: Double = 0.0
)

data class Crop(
    val id: String = "",
    val name: String = "",
    val variety: String = "",
    val emoji: String = "🌾",
    val status: String = "Growing",
    val plantDate: String = "",
    val harvestDate: String = "",
    val area: Double = 0.0,
    val growthPercent: Int = 0,
    val notes: String = ""
)

data class Expense(
    val id: String = "",
    val title: String = "",
    val amount: Double = 0.0,
    val isExpense: Boolean = true,
    val category: String = "",
    val date: String = "",
    val relatedCrop: String = "",
    val emoji: String = "💸"
)

data class Disease(
    val name: String = "",
    val affectedCrops: String = "",
    val severity: String = "MEDIUM",
    val symptoms: String = "",
    val treatment: String = "",
    val emoji: String = "🦠"
)

data class FertilizerTip(
    val cropName: String = "",
    val stage: String = "",
    val fertilizer: String = "",
    val dosage: String = "",
    val timing: String = "",
    val notes: String = "",
    val emoji: String = "🌿"
)

data class WeatherDay(
    val day: String = "",
    val icon: String = "🌤",
    val condition: String = "",
    val highTemp: Int = 0,
    val lowTemp: Int = 0
)

data class ChatMessage(
    val id: String = "",
    val text: String = "",
    val isFromUser: Boolean = true,
    val timestamp: String = ""
)

data class ActivityItem(
    val emoji: String,
    val title: String,
    val description: String,
    val time: String
)
