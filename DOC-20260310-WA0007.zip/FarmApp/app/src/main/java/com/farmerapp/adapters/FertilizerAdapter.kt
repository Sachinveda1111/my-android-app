package com.farmerapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.R
import com.farmerapp.models.FertilizerTip

class FertilizerAdapter(private val tips: List<FertilizerTip>) : RecyclerView.Adapter<FertilizerAdapter.ViewHolder>() {

    inner class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val tvEmoji: TextView = view.findViewById(R.id.tvFertEmoji)
        val tvCrop: TextView = view.findViewById(R.id.tvFertCrop)
        val tvStage: TextView = view.findViewById(R.id.tvFertStage)
        val tvFertilizer: TextView = view.findViewById(R.id.tvFertName)
        val tvDosage: TextView = view.findViewById(R.id.tvFertDosage)
        val tvNotes: TextView = view.findViewById(R.id.tvFertNotes)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_fertilizer_tip, parent, false))

    override fun getItemCount() = tips.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tip = tips[position]
        holder.tvEmoji.text = tip.emoji
        holder.tvCrop.text = tip.cropName
        holder.tvStage.text = tip.stage
        holder.tvFertilizer.text = tip.fertilizer
        holder.tvDosage.text = "Dosage: ${tip.dosage} | ${tip.timing}"
        holder.tvNotes.text = tip.notes
    }
}
