package com.farmerapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.databinding.ItemDiseaseCardBinding
import com.farmerapp.models.Disease

class DiseaseAdapter(private val diseases: List<Disease>) : RecyclerView.Adapter<DiseaseAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemDiseaseCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemDiseaseCardBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = diseases.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val d = diseases[position]
        with(holder.binding) {
            tvDiseaseIcon.text = d.emoji
            tvDiseaseName.text = d.name
            tvAffectedCrop.text = "Affects: ${d.affectedCrops}"
            tvSeverity.text = d.severity
            tvSymptoms.text = d.symptoms
            tvTreatment.text = d.treatment
        }
    }
}
