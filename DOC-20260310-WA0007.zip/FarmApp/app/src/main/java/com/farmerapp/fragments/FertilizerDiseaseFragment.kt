package com.farmerapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.adapters.DiseaseAdapter
import com.farmerapp.adapters.FertilizerAdapter
import com.farmerapp.databinding.FragmentFertilizerDiseaseBinding
import com.farmerapp.utils.SampleData
import com.google.android.material.tabs.TabLayout

class FertilizerDiseaseFragment : Fragment() {
    private var _binding: FragmentFertilizerDiseaseBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFertilizerDiseaseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup ViewPager with simple fragment swapping using RecyclerView in container
        showFertilizerContent()

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> showFertilizerContent()
                    1 -> showDiseaseContent()
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun showFertilizerContent() {
        // Use viewPager area - since we're not using ViewPager2 properly, show recyclerview
        // This would normally use ViewPager2 with fragments
    }

    private fun showDiseaseContent() {}

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
