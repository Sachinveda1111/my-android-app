package com.farmerapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.adapters.WeatherAdapter
import com.farmerapp.databinding.FragmentWeatherBinding
import com.farmerapp.utils.SampleData
import com.farmerapp.utils.SessionManager

class WeatherFragment : Fragment() {
    private var _binding: FragmentWeatherBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentWeatherBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val session = SessionManager(requireContext())
        binding.tvCity.text = "📍 ${session.getFarmLocation()}"

        binding.tvTemperature.text = "28°C"
        binding.tvCondition.text = "Partly Cloudy"
        binding.tvHumidity.text = "65%"
        binding.tvWind.text = "12 km/h"
        binding.tvRainChance.text = "20%"
        binding.tvUV.text = "6 UV"
        binding.tvFeelsLike.text = "31°C"
        binding.tvVisibility.text = "10 km"
        binding.tvFarmingTip.text = "🌱 Farming Tip: Good conditions for irrigation today! Avoid pesticide spraying."

        binding.rvForecast.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = WeatherAdapter(SampleData.getWeatherForecast())
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
