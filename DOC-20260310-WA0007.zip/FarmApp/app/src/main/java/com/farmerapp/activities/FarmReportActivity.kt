package com.farmerapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmerapp.adapters.CropPerformanceAdapter
import com.farmerapp.databinding.ActivityFarmReportBinding
import com.farmerapp.utils.SampleData

class FarmReportActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Farm Report"

        binding.rvCropPerformance.apply {
            layoutManager = LinearLayoutManager(this@FarmReportActivity)
            adapter = CropPerformanceAdapter(SampleData.getCrops())
        }

        binding.btnExport.setOnClickListener {
            Toast.makeText(this, "📊 Farm Report exported as PDF!", Toast.LENGTH_SHORT).show()
        }
    }
}
