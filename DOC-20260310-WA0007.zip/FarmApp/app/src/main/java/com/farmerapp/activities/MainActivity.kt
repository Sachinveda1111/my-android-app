package com.farmerapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.farmerapp.R
import com.farmerapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        val navController = findNavController(R.id.nav_host_fragment)
        binding.bottomNavView.setupWithNavController(navController)

        // Handle report and chat from dashboard
        binding.bottomNavView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> { navController.navigate(R.id.dashboardFragment); true }
                R.id.nav_crops -> { navController.navigate(R.id.cropManagementFragment); true }
                R.id.nav_fertilizer -> { navController.navigate(R.id.fertilizerFragment); true }
                R.id.nav_expense -> { navController.navigate(R.id.expenseFragment); true }
                R.id.nav_weather -> { navController.navigate(R.id.weatherFragment); true }
                else -> false
            }
        }
    }
}
