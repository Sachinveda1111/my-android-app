package com.farmerapp.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmerapp.databinding.ItemExpenseBinding
import com.farmerapp.models.Expense

class ExpenseAdapter(private val expenses: MutableList<Expense>) : RecyclerView.Adapter<ExpenseAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemExpenseBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = expenses.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val exp = expenses[position]
        with(holder.binding) {
            tvExpenseIcon.text = exp.emoji
            tvExpenseTitle.text = exp.title
            tvExpenseCategory.text = "${exp.category} | ${exp.date}"
            if (exp.isExpense) {
                tvExpenseAmount.text = "-₹${String.format("%,.0f", exp.amount)}"
                tvExpenseAmount.setTextColor(Color.parseColor("#D32F2F"))
                tvExpenseType.text = "Expense"
            } else {
                tvExpenseAmount.text = "+₹${String.format("%,.0f", exp.amount)}"
                tvExpenseAmount.setTextColor(Color.parseColor("#2E7D32"))
                tvExpenseType.text = "Income"
            }
        }
    }

    fun updateList(newList: List<Expense>) {
        expenses.clear()
        expenses.addAll(newList)
        notifyDataSetChanged()
    }
}
