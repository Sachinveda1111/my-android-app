package com.farmapp.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.farmapp.databinding.ActivityRegisterBinding
import com.farmapp.ui.main.MainActivity
import com.farmapp.utils.PreferenceManager
import com.farmapp.utils.ValidationUtils

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var preferenceManager: PreferenceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferenceManager = PreferenceManager(this)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnRegister.setOnClickListener { performRegistration() }
        binding.tvLogin.setOnClickListener { finish() }
    }

    private fun performRegistration() {
        val name = binding.etName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val farmName = binding.etFarmName.text.toString().trim()
        val farmLocation = binding.etFarmLocation.text.toString().trim()
        val farmSize = binding.etFarmSize.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()

        if (!validateInputs(name, email, phone, farmName, farmLocation, farmSize, password, confirmPassword)) return

        showLoading(true)

        binding.root.postDelayed({
            showLoading(false)
            preferenceManager.saveUserLoggedIn(true)
            preferenceManager.saveUserEmail(email)
            preferenceManager.saveUserName(name)
            preferenceManager.saveFarmName(farmName)
            preferenceManager.saveFarmLocation(farmLocation)
            Toast.makeText(this, "Welcome to FarmSmart, $name! 🌱", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finishAffinity()
        }, 2000)
    }

    private fun validateInputs(
        name: String, email: String, phone: String,
        farmName: String, farmLocation: String, farmSize: String,
        password: String, confirmPassword: String
    ): Boolean {
        var isValid = true
        clearErrors()

        if (name.isEmpty()) { binding.tilName.error = "Full name is required"; isValid = false }
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email is required"; isValid = false
        } else if (!ValidationUtils.isValidEmail(email)) {
            binding.tilEmail.error = "Enter a valid email"; isValid = false
        }
        if (phone.isEmpty()) { binding.tilPhone.error = "Phone is required"; isValid = false }
        if (farmName.isEmpty()) { binding.tilFarmName.error = "Farm name is required"; isValid = false }
        if (farmLocation.isEmpty()) { binding.tilFarmLocation.error = "Location is required"; isValid = false }
        if (farmSize.isEmpty()) { binding.tilFarmSize.error = "Farm size is required"; isValid = false }
        if (password.isEmpty()) {
            binding.tilPassword.error = "Password is required"; isValid = false
        } else if (password.length < 8) {
            binding.tilPassword.error = "Password must be at least 8 characters"; isValid = false
        }
        if (confirmPassword != password) {
            binding.tilConfirmPassword.error = "Passwords do not match"; isValid = false
        }
        return isValid
    }

    private fun clearErrors() {
        listOf(
            binding.tilName, binding.tilEmail, binding.tilPhone,
            binding.tilFarmName, binding.tilFarmLocation, binding.tilFarmSize,
            binding.tilPassword, binding.tilConfirmPassword
        ).forEach { it.error = null }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !show
        binding.btnRegister.text = if (show) "Creating Account..." else "Create Account"
    }
}
