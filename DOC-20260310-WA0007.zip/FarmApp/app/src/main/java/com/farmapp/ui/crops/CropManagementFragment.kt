package com.farmapp.ui.crops

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmapp.data.model.Crop
import com.farmapp.data.model.CropStatus
import com.farmapp.databinding.FragmentCropManagementBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CropManagementFragment : Fragment() {

    private var _binding: FragmentCropManagementBinding? = null
    private val binding get() = _binding!!

    private lateinit var cropAdapter: CropAdapter
    private val allCrops = mutableListOf<Crop>()
    private var filteredCrops = mutableListOf<Crop>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCropManagementBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadSampleData()
        setupRecyclerView()
        setupFilters()
        setupFab()
        updateStats()
    }

    private fun loadSampleData() {
        allCrops.addAll(listOf(
            Crop("1", "", "Wheat", "Grain Crop", System.currentTimeMillis() - 5184000000L, System.currentTimeMillis() + 3888000000L, 5.0, CropStatus.GROWING, 60, "Growing well in North Field"),
            Crop("2", "", "Tomatoes", "Vegetable Crop", System.currentTimeMillis() - 2592000000L, System.currentTimeMillis() + 1296000000L, 2.0, CropStatus.GROWING, 80, "Ready for harvest soon"),
            Crop("3", "", "Rice", "Grain Crop", System.currentTimeMillis() - 7776000000L, System.currentTimeMillis() - 259200000L, 8.0, CropStatus.HARVESTED, 100, "Excellent yield this season"),
            Crop("4", "", "Cotton", "Cash Crop", System.currentTimeMillis() - 3456000000L, System.currentTimeMillis() + 6480000000L, 10.0, CropStatus.GROWING, 35, "Early growth stage"),
            Crop("5", "", "Potatoes", "Vegetable Crop", System.currentTimeMillis() - 1728000000L, System.currentTimeMillis() + 2160000000L, 3.0, CropStatus.GROWING, 45, "Monitoring for late blight"),
            Crop("6", "", "Soybeans", "Legume Crop", System.currentTimeMillis() - 9331200000L, System.currentTimeMillis() - 3456000000L, 6.0, CropStatus.HARVESTED, 100, "Good protein content"),
            Crop("7", "", "Sunflower", "Oil Crop", System.currentTimeMillis() - 864000000L, System.currentTimeMillis() - 86400000L, 4.0, CropStatus.FAILED, 0, "Lost due to heavy rainfall")
        ))
        filteredCrops.addAll(allCrops)
    }

    private fun setupRecyclerView() {
        cropAdapter = CropAdapter(
            crops = filteredCrops,
            onEditClick = { crop -> showAddEditDialog(crop) },
            onDeleteClick = { crop -> showDeleteConfirmation(crop) }
        )
        binding.rvCrops.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = cropAdapter
        }
        toggleEmptyState()
    }

    private fun setupFilters() {
        binding.chipGroupFilter.setOnCheckedStateChangeListener { group, checkedIds ->
            val checkedId = checkedIds.firstOrNull()
            filteredCrops.clear()
            filteredCrops.addAll(when (checkedId) {
                binding.chipGrowing.id -> allCrops.filter { it.status == CropStatus.GROWING }
                binding.chipHarvested.id -> allCrops.filter { it.status == CropStatus.HARVESTED }
                binding.chipFailed.id -> allCrops.filter { it.status == CropStatus.FAILED }
                else -> allCrops
            })
            cropAdapter.notifyDataSetChanged()
            toggleEmptyState()
        }
    }

    private fun setupFab() {
        binding.fabAddCrop.setOnClickListener { showAddEditDialog(null) }
    }

    private fun showAddEditDialog(crop: Crop?) {
        val dialog = AddEditCropBottomSheet.newInstance(crop)
        dialog.setOnSaveListener { savedCrop ->
            if (crop == null) {
                allCrops.add(0, savedCrop)
                filteredCrops.add(0, savedCrop)
                cropAdapter.notifyItemInserted(0)
                binding.rvCrops.scrollToPosition(0)
            } else {
                val index = filteredCrops.indexOfFirst { it.id == savedCrop.id }
                if (index >= 0) {
                    filteredCrops[index] = savedCrop
                    cropAdapter.notifyItemChanged(index)
                }
            }
            updateStats()
            toggleEmptyState()
        }
        dialog.show(childFragmentManager, "AddEditCrop")
    }

    private fun showDeleteConfirmation(crop: Crop) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Crop")
            .setMessage("Are you sure you want to delete ${crop.name}? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                val index = filteredCrops.indexOf(crop)
                filteredCrops.remove(crop)
                allCrops.remove(crop)
                cropAdapter.notifyItemRemoved(index)
                updateStats()
                toggleEmptyState()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateStats() {
        binding.tvTotalCrops.text = allCrops.size.toString()
        binding.tvGrowingCrops.text = allCrops.count { it.status == CropStatus.GROWING }.toString()
        binding.tvHarvestedCrops.text = allCrops.count { it.status == CropStatus.HARVESTED }.toString()
    }

    private fun toggleEmptyState() {
        binding.layoutEmpty.visibility = if (filteredCrops.isEmpty()) View.VISIBLE else View.GONE
        binding.rvCrops.visibility = if (filteredCrops.isEmpty()) View.GONE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
