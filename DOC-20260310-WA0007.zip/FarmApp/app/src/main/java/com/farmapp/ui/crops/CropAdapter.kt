package com.farmapp.ui.crops

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmapp.data.model.Crop
import com.farmapp.data.model.CropStatus
import com.farmapp.databinding.ItemCropBinding
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class CropAdapter(
    private val crops: MutableList<Crop>,
    private val onEditClick: (Crop) -> Unit,
    private val onDeleteClick: (Crop) -> Unit
) : RecyclerView.Adapter<CropAdapter.CropViewHolder>() {

    inner class CropViewHolder(val binding: ItemCropBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CropViewHolder {
        val binding = ItemCropBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CropViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CropViewHolder, position: Int) {
        val crop = crops[position]
        holder.binding.apply {

            tvCropName.text = crop.name
            tvCropType.text = crop.type
            tvFieldSize.text = "${crop.fieldSize} acres"

            // Planting date
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            tvPlantingDate.text = dateFormat.format(Date(crop.plantingDate))

            // Days to harvest
            val daysLeft = TimeUnit.MILLISECONDS.toDays(crop.expectedHarvestDate - System.currentTimeMillis())
            tvDaysToHarvest.text = when {
                crop.status == CropStatus.HARVESTED -> "✓ Done"
                crop.status == CropStatus.FAILED -> "✗ Failed"
                daysLeft <= 0 -> "Ready!"
                else -> "$daysLeft days"
            }

            // Growth progress
            progressGrowth.progress = crop.growthProgress
            tvGrowthPercent.text = "${crop.growthProgress}%"

            // Status badge
            tvCropStatus.text = crop.status.name
            val (bgColor, textColor) = when (crop.status) {
                CropStatus.GROWING -> Pair("#4CAF50", "#FFFFFF")
                CropStatus.HARVESTED -> Pair("#1976D2", "#FFFFFF")
                CropStatus.FAILED -> Pair("#E53935", "#FFFFFF")
            }
            tvCropStatus.setBackgroundColor(Color.parseColor(bgColor))
            tvCropStatus.setTextColor(Color.parseColor(textColor))

            // Accent bar color
            viewAccent.setBackgroundColor(Color.parseColor(when (crop.status) {
                CropStatus.GROWING -> "#4CAF50"
                CropStatus.HARVESTED -> "#1976D2"
                CropStatus.FAILED -> "#E53935"
            }))

            // Crop icon emoji based on type
            ivCropIcon.setImageResource(getCropIcon(crop.name))

            btnEdit.setOnClickListener { onEditClick(crop) }
            btnDelete.setOnClickListener { onDeleteClick(crop) }
        }
    }

    private fun getCropIcon(cropName: String): Int {
        return com.farmapp.R.drawable.ic_crop // Use specific icons per crop in production
    }

    override fun getItemCount() = crops.size
}
