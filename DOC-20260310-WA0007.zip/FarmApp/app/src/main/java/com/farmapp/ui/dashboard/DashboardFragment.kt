package com.farmapp.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmapp.R
import com.farmapp.data.model.*
import com.farmapp.databinding.FragmentDashboardBinding
import com.farmapp.ui.main.MainActivity
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private lateinit var activitiesAdapter: RecentActivitiesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupRecyclerView()
        loadDashboardData()
        setupQuickActions()
    }

    private fun setupUI() {
        // Set greeting based on time of day
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        binding.tvGreeting.text = when {
            hour < 12 -> "Good Morning! 🌅"
            hour < 17 -> "Good Afternoon! ☀️"
            else -> "Good Evening! 🌙"
        }

        // Set date
        val dateFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
        binding.tvTodayDate.text = dateFormat.format(Date())

        // Set farmer name (from preferences in real app)
        binding.tvFarmerName.text = "Your Farm"
    }

    private fun setupRecyclerView() {
        activitiesAdapter = RecentActivitiesAdapter(getSampleActivities())
        binding.rvRecentActivities.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = activitiesAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun loadDashboardData() {
        // Load real data from repository in production
        binding.tvActiveCrops.text = "5"
        binding.tvTotalExpense.text = "₹12,400"
        binding.tvNetProfit.text = "₹8,600"
        binding.tvFarmHealth.text = "85%"

        // Weather data
        binding.tvTemperature.text = "28°C"
        binding.tvWeatherDesc.text = "Sunny — Great for farming"
        binding.tvWeatherLocation.text = "📍 Punjab, India"
    }

    private fun setupQuickActions() {
        binding.quickAddCrop.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_crops)
        }
        binding.quickAddExpense.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_expense)
        }
        binding.quickWeather.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_weather)
        }
        binding.quickChat.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_chat)
        }
        binding.cardWeather.setOnClickListener {
            (activity as? MainActivity)?.navigateToTab(R.id.nav_weather)
        }
        binding.tvViewAll.setOnClickListener {
            // Show all activities
        }
    }

    private fun getSampleActivities(): List<FarmActivity> = listOf(
        FarmActivity("1", "Wheat Crop Updated", "Growth progress: 60% — on track for harvest", ActivityType.CROP_UPDATE, System.currentTimeMillis() - 3600000),
        FarmActivity("2", "Fertilizer Applied", "NPK fertilizer applied to rice field (3 acres)", ActivityType.FERTILIZER_APPLIED, System.currentTimeMillis() - 7200000),
        FarmActivity("3", "Expense Recorded", "Labor cost: ₹2,500 for planting season", ActivityType.EXPENSE_ADDED, System.currentTimeMillis() - 86400000),
        FarmActivity("4", "Weather Alert", "Heavy rain expected tomorrow — secure crops", ActivityType.WEATHER_ALERT, System.currentTimeMillis() - 172800000),
        FarmActivity("5", "Tomato Harvested", "Harvested 450 kg from field B", ActivityType.HARVEST, System.currentTimeMillis() - 259200000)
    )

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
