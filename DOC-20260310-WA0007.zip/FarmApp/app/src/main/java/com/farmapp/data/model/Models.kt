package com.farmapp.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ===================== USER MODEL =====================
@Parcelize
data class User(
    val id: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val farmName: String = "",
    val farmLocation: String = "",
    val farmSize: Double = 0.0,
    val profileImageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

// ===================== CROP MODEL =====================
@Parcelize
data class Crop(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val type: String = "",
    val plantingDate: Long = 0L,
    val expectedHarvestDate: Long = 0L,
    val fieldSize: Double = 0.0,
    val status: CropStatus = CropStatus.GROWING,
    val growthProgress: Int = 0,
    val notes: String = "",
    val imageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

enum class CropStatus {
    GROWING, HARVESTED, FAILED
}

// ===================== EXPENSE MODEL =====================
@Parcelize
data class Expense(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val amount: Double = 0.0,
    val category: ExpenseCategory = ExpenseCategory.OTHER,
    val type: TransactionType = TransactionType.EXPENSE,
    val date: Long = System.currentTimeMillis(),
    val cropId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

enum class ExpenseCategory(val displayName: String, val emoji: String) {
    SEEDS("Seeds", "🌱"),
    FERTILIZER("Fertilizer", "🧪"),
    PESTICIDE("Pesticide", "🐛"),
    LABOR("Labor", "👷"),
    EQUIPMENT("Equipment", "🚜"),
    IRRIGATION("Irrigation", "💧"),
    INCOME("Income", "💰"),
    OTHER("Other", "📦")
}

enum class TransactionType {
    INCOME, EXPENSE
}

// ===================== WEATHER MODEL =====================
data class WeatherData(
    val temperature: Double = 0.0,
    val feelsLike: Double = 0.0,
    val humidity: Int = 0,
    val windSpeed: Double = 0.0,
    val rainfall: Double = 0.0,
    val uvIndex: Int = 0,
    val condition: String = "",
    val conditionCode: Int = 0,
    val visibility: Double = 0.0,
    val pressure: Double = 0.0,
    val location: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class ForecastDay(
    val date: Long = 0L,
    val dayName: String = "",
    val maxTemp: Double = 0.0,
    val minTemp: Double = 0.0,
    val condition: String = "",
    val conditionCode: Int = 0,
    val rainfall: Double = 0.0,
    val humidity: Int = 0
)

// ===================== DISEASE MODEL =====================
data class Disease(
    val id: String = "",
    val name: String = "",
    val affectedCrops: List<String> = emptyList(),
    val symptoms: String = "",
    val treatment: String = "",
    val prevention: String = "",
    val severity: DiseaseSeverity = DiseaseSeverity.MODERATE,
    val imageUrl: String = ""
)

enum class DiseaseSeverity(val label: String, val colorHex: String) {
    LOW("Low", "#43A047"),
    MODERATE("Moderate", "#FB8C00"),
    HIGH("High", "#E53935"),
    CRITICAL("Critical", "#B71C1C")
}

// ===================== FERTILIZER MODEL =====================
data class FertilizerGuide(
    val cropName: String = "",
    val nitrogenKgPerAcre: Double = 0.0,
    val phosphorusKgPerAcre: Double = 0.0,
    val potassiumKgPerAcre: Double = 0.0,
    val applicationSchedule: List<ApplicationSchedule> = emptyList(),
    val organicAlternatives: List<String> = emptyList()
)

data class ApplicationSchedule(
    val stage: String = "",
    val daysAfterPlanting: Int = 0,
    val fertilizer: String = "",
    val quantity: String = "",
    val method: String = ""
)

// ===================== CHAT MODEL =====================
data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isFromUser: Boolean = true,
    val isRead: Boolean = false,
    val messageType: MessageType = MessageType.TEXT
)

enum class MessageType { TEXT, IMAGE, VOICE }

data class ChatContact(
    val id: String = "",
    val name: String = "",
    val avatarUrl: String = "",
    val lastMessage: String = "",
    val lastMessageTime: Long = 0L,
    val unreadCount: Int = 0,
    val isOnline: Boolean = false,
    val isAI: Boolean = false
)

// ===================== ACTIVITY MODEL =====================
data class FarmActivity(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val activityType: ActivityType = ActivityType.CROP_UPDATE,
    val timestamp: Long = System.currentTimeMillis(),
    val relatedItemId: String = ""
)

enum class ActivityType(val emoji: String) {
    CROP_UPDATE("🌱"),
    EXPENSE_ADDED("💰"),
    HARVEST("🌾"),
    DISEASE_DETECTED("⚠️"),
    WEATHER_ALERT("🌦"),
    FERTILIZER_APPLIED("🧪")
}
