package com.farmapp.ui.expense

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.farmapp.data.model.Expense
import com.farmapp.data.model.ExpenseCategory
import com.farmapp.data.model.TransactionType
import com.farmapp.databinding.FragmentExpenseTrackerBinding
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry

class ExpenseTrackerFragment : Fragment() {

    private var _binding: FragmentExpenseTrackerBinding? = null
    private val binding get() = _binding!!
    private lateinit var transactionAdapter: TransactionAdapter
    private val transactions = mutableListOf<Expense>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExpenseTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadSampleData()
        setupRecyclerView()
        setupPieChart()
        setupFab()
        updateSummary()
    }

    private fun loadSampleData() {
        transactions.addAll(listOf(
            Expense("1", "", "Wheat Seeds", "High-yield wheat seeds", 4200.0, ExpenseCategory.SEEDS, TransactionType.EXPENSE, System.currentTimeMillis() - 864000000L),
            Expense("2", "", "NPK Fertilizer", "Applied to all fields", 6500.0, ExpenseCategory.FERTILIZER, TransactionType.EXPENSE, System.currentTimeMillis() - 1728000000L),
            Expense("3", "", "Labor Wages", "Planting season labor", 8900.0, ExpenseCategory.LABOR, TransactionType.EXPENSE, System.currentTimeMillis() - 2592000000L),
            Expense("4", "", "Drip Irrigation", "Irrigation system maintenance", 3200.0, ExpenseCategory.IRRIGATION, TransactionType.EXPENSE, System.currentTimeMillis() - 3456000000L),
            Expense("5", "", "Tractor Hire", "Land preparation", 2600.0, ExpenseCategory.EQUIPMENT, TransactionType.EXPENSE, System.currentTimeMillis() - 4320000000L),
            Expense("6", "", "Wheat Sale", "Sold 500 quintals @₹2,000", 100000.0, ExpenseCategory.INCOME, TransactionType.INCOME, System.currentTimeMillis() - 5184000000L),
            Expense("7", "", "Tomato Sale", "Local market sale", 18000.0, ExpenseCategory.INCOME, TransactionType.INCOME, System.currentTimeMillis() - 6048000000L),
            Expense("8", "", "Pesticide Spray", "Pest control treatment", 2800.0, ExpenseCategory.PESTICIDE, TransactionType.EXPENSE, System.currentTimeMillis() - 6912000000L)
        ))
    }

    private fun setupRecyclerView() {
        transactionAdapter = TransactionAdapter(transactions)
        binding.rvTransactions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = transactionAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun setupPieChart() {
        val expenses = transactions.filter { it.type == TransactionType.EXPENSE }
        val categoryTotals = expenses.groupBy { it.category }
            .map { (cat, items) -> PieEntry(items.sumOf { it.amount }.toFloat(), cat.emoji) }

        val dataSet = PieDataSet(categoryTotals, "Expenses").apply {
            colors = listOf(
                Color.parseColor("#4CAF50"), Color.parseColor("#FF9800"),
                Color.parseColor("#2196F3"), Color.parseColor("#00BCD4"),
                Color.parseColor("#E91E63"), Color.parseColor("#9C27B0")
            )
            valueTextColor = Color.WHITE
            valueTextSize = 11f
        }

        binding.pieChart.apply {
            data = PieData(dataSet)
            description.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 50f
            setHoleColor(Color.WHITE)
            setCenterText("Expenses")
            setCenterTextSize(14f)
            legend.isEnabled = true
            animateXY(800, 800)
            invalidate()
        }
    }

    private fun setupFab() {
        binding.fabAddExpense.setOnClickListener {
            val dialog = AddExpenseBottomSheet.newInstance()
            dialog.setOnSaveListener { expense ->
                transactions.add(0, expense)
                transactionAdapter.notifyItemInserted(0)
                updateSummary()
                setupPieChart()
            }
            dialog.show(childFragmentManager, "AddExpense")
        }
    }

    private fun updateSummary() {
        val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val profit = income - expense

        binding.tvTotalIncome.text = "₹ ${String.format("%,.0f", income)}"
        binding.tvTotalExpense.text = "₹ ${String.format("%,.0f", expense)}"
        binding.tvNetProfit.text = "₹ ${String.format("%,.0f", profit)}"

        // Category breakdowns
        fun catTotal(cat: ExpenseCategory) = transactions
            .filter { it.category == cat && it.type == TransactionType.EXPENSE }
            .sumOf { it.amount }

        binding.tvSeedsAmount.text = "₹${String.format("%,.0f", catTotal(ExpenseCategory.SEEDS))}"
        binding.tvFertilizerAmount.text = "₹${String.format("%,.0f", catTotal(ExpenseCategory.FERTILIZER))}"
        binding.tvLaborAmount.text = "₹${String.format("%,.0f", catTotal(ExpenseCategory.LABOR))}"
        binding.tvIrrigationAmount.text = "₹${String.format("%,.0f", catTotal(ExpenseCategory.IRRIGATION))}"
        binding.tvEquipmentAmount.text = "₹${String.format("%,.0f", catTotal(ExpenseCategory.EQUIPMENT))}"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
