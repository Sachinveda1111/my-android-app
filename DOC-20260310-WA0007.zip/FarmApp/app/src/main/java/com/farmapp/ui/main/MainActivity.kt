package com.farmapp.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.farmapp.R
import com.farmapp.databinding.ActivityMainBinding
import com.farmapp.ui.auth.LoginActivity
import com.farmapp.ui.crops.CropManagementFragment
import com.farmapp.ui.dashboard.DashboardFragment
import com.farmapp.ui.expense.ExpenseTrackerFragment
import com.farmapp.ui.fertilizer.FertilizerDiseaseFragment
import com.farmapp.ui.reports.ReportsFragment
import com.farmapp.ui.weather.WeatherFragment
import com.farmapp.ui.chat.ChatListFragment
import com.farmapp.utils.PreferenceManager
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferenceManager: PreferenceManager

    private val dashboardFragment = DashboardFragment()
    private val cropFragment = CropManagementFragment()
    private val fertilizerFragment = FertilizerDiseaseFragment()
    private val expenseFragment = ExpenseTrackerFragment()
    private val weatherFragment = WeatherFragment()
    private val reportsFragment = ReportsFragment()
    private val chatFragment = ChatListFragment()

    private var activeFragment: Fragment = dashboardFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferenceManager = PreferenceManager(this)

        setupToolbar()
        setupFragments()
        setupBottomNavigation()
        setupProfileClick()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(true)
        updateToolbarTitle(R.id.nav_dashboard)
    }

    private fun setupFragments() {
        supportFragmentManager.beginTransaction().apply {
            add(R.id.nav_host_fragment, dashboardFragment, "dashboard")
            add(R.id.nav_host_fragment, cropFragment, "crops").hide(cropFragment)
            add(R.id.nav_host_fragment, fertilizerFragment, "fertilizer").hide(fertilizerFragment)
            add(R.id.nav_host_fragment, expenseFragment, "expense").hide(expenseFragment)
            add(R.id.nav_host_fragment, weatherFragment, "weather").hide(weatherFragment)
            add(R.id.nav_host_fragment, reportsFragment, "reports").hide(reportsFragment)
            add(R.id.nav_host_fragment, chatFragment, "chat").hide(chatFragment)
        }.commit()
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            navigateToFragment(item.itemId)
            updateToolbarTitle(item.itemId)
            true
        }
    }

    private fun navigateToFragment(itemId: Int) {
        val targetFragment = when (itemId) {
            R.id.nav_dashboard -> dashboardFragment
            R.id.nav_crops -> cropFragment
            R.id.nav_fertilizer -> fertilizerFragment
            R.id.nav_expense -> expenseFragment
            R.id.nav_weather -> weatherFragment
            R.id.nav_reports -> reportsFragment
            R.id.nav_chat -> chatFragment
            else -> dashboardFragment
        }

        if (targetFragment != activeFragment) {
            supportFragmentManager.beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .hide(activeFragment)
                .show(targetFragment)
                .commit()
            activeFragment = targetFragment
        }
    }

    private fun updateToolbarTitle(itemId: Int) {
        val title = when (itemId) {
            R.id.nav_dashboard -> "🌿 FarmSmart"
            R.id.nav_crops -> "🌾 Crop Management"
            R.id.nav_fertilizer -> "🧪 Fertilizer & Disease"
            R.id.nav_expense -> "💰 Expense Tracker"
            R.id.nav_weather -> "🌤 Weather Forecast"
            R.id.nav_reports -> "📊 Farm Reports"
            R.id.nav_chat -> "💬 Messages"
            else -> "FarmSmart"
        }
        binding.toolbar.title = title
        supportActionBar?.title = title
        binding.toolbar.subtitle = preferenceManager.getFarmName() ?: ""
    }

    private fun setupProfileClick() {
        binding.ivProfile.setOnClickListener {
            // Navigate to profile or show menu
            showProfileMenu()
        }
    }

    private fun showProfileMenu() {
        val popup = androidx.appcompat.widget.PopupMenu(this, binding.ivProfile)
        popup.menu.apply {
            add(0, 1, 0, "👤 Profile Settings")
            add(0, 2, 0, "⚙️ App Settings")
            add(0, 3, 0, "❓ Help & Support")
            add(0, 4, 0, "🚪 Logout")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                4 -> performLogout()
            }
            true
        }
        popup.show()
    }

    private fun performLogout() {
        preferenceManager.clearAll()
        startActivity(Intent(this, LoginActivity::class.java))
        finishAffinity()
    }

    fun navigateToTab(tabId: Int) {
        binding.bottomNavigation.selectedItemId = tabId
    }
}
