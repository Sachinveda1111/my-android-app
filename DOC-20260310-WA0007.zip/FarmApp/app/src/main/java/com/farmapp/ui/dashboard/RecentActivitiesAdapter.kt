package com.farmapp.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmapp.data.model.ActivityType
import com.farmapp.data.model.FarmActivity
import com.farmapp.databinding.ItemActivityBinding
import java.text.SimpleDateFormat
import java.util.*

class RecentActivitiesAdapter(
    private val activities: List<FarmActivity>
) : RecyclerView.Adapter<RecentActivitiesAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemActivityBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemActivityBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val activity = activities[position]
        holder.binding.apply {
            tvActivityEmoji.text = activity.activityType.emoji
            tvActivityTitle.text = activity.title
            tvActivityDesc.text = activity.description
            tvActivityTime.text = formatTime(activity.timestamp)

            // Color accent based on type
            val bgColor = when (activity.activityType) {
                ActivityType.CROP_UPDATE -> "#E8F5E9"
                ActivityType.EXPENSE_ADDED -> "#FFF8E1"
                ActivityType.HARVEST -> "#E8F5E9"
                ActivityType.DISEASE_DETECTED -> "#FFEBEE"
                ActivityType.WEATHER_ALERT -> "#E3F2FD"
                ActivityType.FERTILIZER_APPLIED -> "#F3E5F5"
            }
        }
    }

    private fun formatTime(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        return when {
            diff < 3600000 -> "${diff / 60000} min ago"
            diff < 86400000 -> "${diff / 3600000}h ago"
            diff < 604800000 -> "${diff / 86400000}d ago"
            else -> SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(timestamp))
        }
    }

    override fun getItemCount() = activities.size
}
