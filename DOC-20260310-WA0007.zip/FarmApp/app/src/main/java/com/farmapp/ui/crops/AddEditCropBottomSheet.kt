package com.farmapp.ui.crops

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.farmapp.data.model.Crop
import com.farmapp.data.model.CropStatus
import com.farmapp.databinding.BottomsheetAddCropBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.text.SimpleDateFormat
import java.util.*

class AddEditCropBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomsheetAddCropBinding? = null
    private val binding get() = _binding!!
    private var onSaveListener: ((Crop) -> Unit)? = null
    private var existingCrop: Crop? = null
    private var plantingDate: Long = System.currentTimeMillis()
    private var harvestDate: Long = System.currentTimeMillis() + 7776000000L // 90 days

    companion object {
        fun newInstance(crop: Crop? = null): AddEditCropBottomSheet {
            return AddEditCropBottomSheet().apply {
                existingCrop = crop
            }
        }
    }

    fun setOnSaveListener(listener: (Crop) -> Unit) {
        onSaveListener = listener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = BottomsheetAddCropBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        existingCrop?.let { populateFields(it) }
        setupDatePickers()
        setupButtons()
        updateDateTexts()
    }

    private fun populateFields(crop: Crop) {
        binding.tvSheetTitle.text = "Edit Crop"
        binding.etCropName.setText(crop.name)
        binding.etCropType.setText(crop.type)
        binding.etFieldSize.setText(crop.fieldSize.toString())
        binding.etNotes.setText(crop.notes)
        plantingDate = crop.plantingDate
        harvestDate = crop.expectedHarvestDate

        when (crop.status) {
            CropStatus.GROWING -> binding.rgStatus.check(binding.rbGrowing.id)
            CropStatus.HARVESTED -> binding.rgStatus.check(binding.rbHarvested.id)
            CropStatus.FAILED -> binding.rgStatus.check(binding.rbFailed.id)
        }
    }

    private fun setupDatePickers() {
        binding.tvPlantingDate.setOnClickListener { showDatePicker(true) }
        binding.tvHarvestDate.setOnClickListener { showDatePicker(false) }
    }

    private fun showDatePicker(isPlanting: Boolean) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = if (isPlanting) plantingDate else harvestDate
        DatePickerDialog(requireContext(), { _, year, month, day ->
            cal.set(year, month, day)
            if (isPlanting) plantingDate = cal.timeInMillis
            else harvestDate = cal.timeInMillis
            updateDateTexts()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateDateTexts() {
        val fmt = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        binding.tvPlantingDate.text = fmt.format(Date(plantingDate))
        binding.tvHarvestDate.text = fmt.format(Date(harvestDate))
    }

    private fun setupButtons() {
        binding.btnSave.setOnClickListener { saveCrop() }
        binding.btnCancel.setOnClickListener { dismiss() }
    }

    private fun saveCrop() {
        val name = binding.etCropName.text.toString().trim()
        val type = binding.etCropType.text.toString().trim()
        val fieldSize = binding.etFieldSize.text.toString().toDoubleOrNull() ?: 0.0

        if (name.isEmpty()) {
            binding.tilCropName.error = "Crop name is required"
            return
        }

        val status = when (binding.rgStatus.checkedRadioButtonId) {
            binding.rbGrowing.id -> CropStatus.GROWING
            binding.rbHarvested.id -> CropStatus.HARVESTED
            binding.rbFailed.id -> CropStatus.FAILED
            else -> CropStatus.GROWING
        }

        val crop = (existingCrop ?: Crop(id = UUID.randomUUID().toString())).copy(
            name = name,
            type = type.ifEmpty { "General Crop" },
            plantingDate = plantingDate,
            expectedHarvestDate = harvestDate,
            fieldSize = fieldSize,
            status = status,
            notes = binding.etNotes.text.toString().trim()
        )

        onSaveListener?.invoke(crop)
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
