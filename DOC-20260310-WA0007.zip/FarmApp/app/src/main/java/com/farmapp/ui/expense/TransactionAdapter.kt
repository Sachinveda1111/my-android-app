package com.farmapp.ui.expense

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.farmapp.data.model.Expense
import com.farmapp.data.model.TransactionType
import com.farmapp.databinding.ItemTransactionBinding
import java.text.SimpleDateFormat
import java.util.*

class TransactionAdapter(
    private val transactions: List<Expense>
) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val expense = transactions[position]
        holder.binding.apply {
            tvEmoji.text = expense.category.emoji
            tvTitle.text = expense.title
            tvDescription.text = expense.description
            tvDate.text = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(expense.date))

            if (expense.type == TransactionType.INCOME) {
                tvAmount.text = "+ ₹${String.format("%,.0f", expense.amount)}"
                tvAmount.setTextColor(Color.parseColor("#43A047"))
                tvType.text = "INCOME"
                tvType.setBackgroundColor(Color.parseColor("#E8F5E9"))
                tvType.setTextColor(Color.parseColor("#2E7D32"))
            } else {
                tvAmount.text = "- ₹${String.format("%,.0f", expense.amount)}"
                tvAmount.setTextColor(Color.parseColor("#E53935"))
                tvType.text = expense.category.displayName.uppercase()
                tvType.setBackgroundColor(Color.parseColor("#FFEBEE"))
                tvType.setTextColor(Color.parseColor("#C62828"))
            }
        }
    }

    override fun getItemCount() = transactions.size
}
