package com.farmapp.ui.expense

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.farmapp.data.model.Expense
import com.farmapp.data.model.ExpenseCategory
import com.farmapp.data.model.TransactionType
import com.farmapp.databinding.BottomsheetAddExpenseBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.util.*

class AddExpenseBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomsheetAddExpenseBinding? = null
    private val binding get() = _binding!!
    private var onSaveListener: ((Expense) -> Unit)? = null

    companion object {
        fun newInstance() = AddExpenseBottomSheet()
    }

    fun setOnSaveListener(listener: (Expense) -> Unit) { onSaveListener = listener }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = BottomsheetAddExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupCategoryDropdown()
        setupButtons()
        setupTypeSwitch()
    }

    private fun setupCategoryDropdown() {
        val categories = ExpenseCategory.values().map { "${it.emoji} ${it.displayName}" }
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, categories)
        binding.actvCategory.setAdapter(adapter)
        binding.actvCategory.setText(categories[0], false)
    }

    private fun setupTypeSwitch() {
        binding.switchType.setOnCheckedChangeListener { _, isChecked ->
            binding.tvTypeLabel.text = if (isChecked) "💰 Income" else "💸 Expense"
        }
    }

    private fun setupButtons() {
        binding.btnSave.setOnClickListener { saveExpense() }
        binding.btnCancel.setOnClickListener { dismiss() }
    }

    private fun saveExpense() {
        val title = binding.etTitle.text.toString().trim()
        val amountStr = binding.etAmount.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()

        if (title.isEmpty()) { binding.tilTitle.error = "Title required"; return }
        if (amountStr.isEmpty()) { binding.tilAmount.error = "Amount required"; return }

        val amount = amountStr.toDoubleOrNull() ?: 0.0
        val isIncome = binding.switchType.isChecked
        val categoryIndex = ExpenseCategory.values().indexOfFirst {
            "${it.emoji} ${it.displayName}" == binding.actvCategory.text.toString()
        }.coerceAtLeast(0)

        val expense = Expense(
            id = UUID.randomUUID().toString(),
            title = title,
            description = description,
            amount = amount,
            category = if (isIncome) ExpenseCategory.INCOME else ExpenseCategory.values()[categoryIndex],
            type = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE
        )

        onSaveListener?.invoke(expense)
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
